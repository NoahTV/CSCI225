/**
 * LandSpeeder.java
 * 145 project
 *
 * Noah Vanderhoff
 * 2020/4/17
 */


public class LandSpeeder {

    public double begin3()
	{
		double dice = (Math.random() * 100); // generates random number between 1 and 100 to see if player wins

		System.out.println("You stake out the known trade route on a sandy desert planet and lie in wait for the Armored Land Speeder."); // flavor text to set the mood
		System.out.println("After about ten minutes, you hear the engine of the vehicle loaded down with credits coming your way.");

		if(dice <= 79) // if roll is under or equal to 79, it is a success.
		{
			System.out.println("You ride your speeder bike into the middle of the road and catch the driver off gaurd." ); // more flavor text
			System.out.println("They swerve off the road to miss you and go into a roll that sends them crashing into the sands beside the road." );
			System.out.println("You check the gaurds and find they are all unconscious. Looks like luck is on your side today." );
			System.out.println("You manage to get away with 27000 credits");
			return 27000;
		}
		else
		{
			System.out.println("You ride your speeder bike into the middle of the road and catch the driver off gaurd." ); // even more flavor text
			System.out.println("They slam on the breaks and stop about ten feet in front of you." );
			System.out.println("Just as you are about to demand their surender all 7 gaurds quikly unload with high-powered laser rifles and fire without warning." );
			System.out.println("You barely escape in time and return with no profit." );
			return 0;
		}
	}


}