/**
 * MosEisleyCantina.java
 *
 * MosEisleyCantina application
 *
 * Jonathan Walker
 * jew6@usca.edu
 * Final project job #1: Mos Eisley Cantina Heist
 * Last modified: 04/22/2020
 */

public class MosEisleyCantina {

    public double begin1(String[][] c) {

    	String gunman = c[0][0];
    	double dice=(Math.random()*100);// Noah used the dice and math in his code, so I think those would work for the other jobs, including this one.

    	System.out.println("You and "+gunman+" enter Mos Eisley Cantina.");
    	System.out.println("You both enter in with disguises and sourced weapons.");
    	System.out.println("You both fire warning shots and get everyone's attention.");
    	System.out.println("You tell the bartender to empty the register while "+gunman+" is on crowd control.");

    	// changed the success rate to 90 percent because it's the easiest job
    	// so if the dice roll is less than or equal to 90, then the job gets done without any trouble
    	if(dice <= 90)
    	{
    		System.out.println("You and "+gunman+" keep firing warning shots to scare any customers that would try to be heros.");
    		System.out.println("The bartender empties the register, and you and "+gunman+" make it out of the store with 5000 credits.");
    		System.out.println("You manage to evade the cops and split the take 50-50.");
    		System.out.println("You both split off to avoid further attention and keep your heads down.");
    		return 2500;
    	}
    	// if the dice is greater than 90
    	else
    	{
    		System.out.println("A few customers try to be heros with concealed blaster pistols.");
    		System.out.println("You and "+gunman+" are forced to put them down.");
    		System.out.println("The cops are notified that a few hostages have been killed, and will come at you in force.");
    		System.out.println("You and "+gunman+" are forced to kill the bartender and take what little money he put in the bag.");
    		System.out.println("You barely managed to get evade the cops and get away with 2000 credits.");
    		System.out.println("You split the take 50-50 and take off to keep a low profile.");
    		return 1000;
    	}
    }
}
