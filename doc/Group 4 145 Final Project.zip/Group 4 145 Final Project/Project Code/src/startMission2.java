// programmed by Miles Trammell
public class startMission2
{
	public static double begin2(String[][] c)
	{
		String gunmen = c[0][0];
		String driver = c[1][0];
		String hacker = c[2][0];
		double dice = (Math.random() * 100); // generates random number between 1 and 100 to see if player wins

		// story
		System.out.println(driver + " drops you " + gunmen + " and " + hacker + " off near the outskirts of town.");
		System.out.println("You and the crew sneak into the spaceport savings bank without being spotted.");
		System.out.println("This desert planet has low security so " + hacker + " is able to hack into the savings account.");

		if(dice <= 72) // if roll is under or equal to 72, it is a success.
		{
			// success story
			System.out.println("You a collecting so many credits but,");
			System.out.println(hacker + " hears footsteps and decides it is time to leave");
			System.out.println("It was difficult but, you decied 40,000 credits is enough.");
			System.out.println("You manage to get away with 40,000 credits and split it evenly.");
			return 10000;
		}
		else
		{
			// failure story
			System.out.println(gunmen + " says there are guards at the gate.");
			System.out.println("You don't listen to him.");
			System.out.println("Watching the credits going up on the display is too intoxicating.");
			System.out.println("The guards burst in through the gate.");
			System.out.println("It was at that moment, you relized the horrible mistake you have made.");
			System.out.println("You fail the job and leave with 0 credits");
			return 0;
		}
	}

}
