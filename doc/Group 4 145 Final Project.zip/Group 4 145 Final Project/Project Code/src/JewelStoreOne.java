/**
 * JewelStoreOne.java
 *
 * JewelStoreOne application
 *
 * Ashley Philbeck
 * @version 1.00 2020/4/25
 */

public class JewelStoreOne {


    public double begin4(String[][] c) {

    	String gunman = c[0][0];
    	String driver = c[1][0];
    	String hacker = c[2][0];
    	double dice=(Math.random()*100);// Noah used the dice and math in his code, so I think those would work for the other jobs, including this one.

    	System.out.println("You, "+hacker+", and "+gunman+" enter Jewel Store.");
    	System.out.println(driver+" waits in the car for you all to return.");
    	System.out.println("All three of you enter in with disguises and sourced weapons.");
    	System.out.println("You and "+gunman+" fire warning shots and get everyone's attention.");
    	System.out.println("You tell the jeweler to empty the safe while "+gunman+" is on crowd control.");
    	System.out.println(hacker+" runs to the back to open all of the safes.");

    	//  if the dice roll is less than or equal to 61, then the job gets done without any trouble
    	if(dice <= 61)
    	{
    		System.out.println("You and "+gunman+" keep firing warning shots to scare any customers that would try to be heros.");
    		System.out.println("The jeweler empties the register, and you, "+gunman+", and "+hacker+" make it out of the store with the credits.");
    		System.out.println("You manage to evade the cops thanks to "+driver+" and split the take.");
    		System.out.println("You all split off to avoid further attention and keep your heads down.");
    		return 1000000;
    	}
    	// if the dice is greater than
    	else
    	{
    		System.out.println("A few customers try to be heros with concealed blaster pistols.");
    		System.out.println("You and "+gunman+" are forced to put them down.");
    		System.out.println("The cops are notified that a few hostages have been killed, and will come at you in force.");
    		System.out.println("You and "+gunman+" are forced to kill the bartender and take what little money he put in the bag.");
    		System.out.println("You all barely managed to  evade the cops and get away with 2000 credits.");
    		System.out.println("You split the take and take off to keep a low profile.");
    		return 500;
    	}
    }
}

