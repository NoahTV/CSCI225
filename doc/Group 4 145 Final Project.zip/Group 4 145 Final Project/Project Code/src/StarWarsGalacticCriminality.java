// programmed by Miles Trammell
import java.util.Scanner;

public class StarWarsGalacticCriminality
{
	int gunmen = 0;
	int drivers = 0;
	int hacker = 0;
	double credits = 2000;

	  // Getter
	  public int getGunmen() {
	    return gunmen;
	  }

	  // Setter
	  public void setGunmen(int gunmen) {
	    this.gunmen = gunmen;
	  }

	  // Getter
	  public int getDrivers() {
	    return drivers;
	  }

	  // Setter
	  public void setDrivers(int drivers) {
	    this.drivers = drivers;
	  }

	  // Getter
	  public int getHacker() {
	    return hacker;
	  }

	  // Setter
	  public void setHacker(int hacker) {
	    this.hacker = hacker;
	  }

	  // Getter
	  public double getCredits() {
	    return credits;
	  }

	  // Setter
	  public void setCredits(double credits) {
	    this.credits = credits;
	  }

	  // Setter
	  public void addGunmen(int gunmen) {
	    this.gunmen = gunmen + 1;
	  }

	  // Setter
	  public void addDrivers(int drivers) {
	    this.drivers = drivers + 1;
	  }

	  // Setter
	  public void addHacker(int hacker) {
	    this.hacker = hacker + 1;
	  }

	  public void subtract100Credits(double credits) {
		    this.credits = credits -100;
		  }

	  public void subtract200Credits(double credits) {
		    this.credits = credits -200;
		  }
}
