// programmed by Miles Trammell and clean up by Noah Vanderhoff
// note you may to scroll up to see output
import java.util.Random;
import java.util.Scanner;

public class StarWarsGalacticCriminalityTest
{
	static boolean running = true;
	static Scanner scanner = new Scanner(System.in);
	static StarWarsGalacticCriminality gc = new StarWarsGalacticCriminality();
	// 20 characters from each category can be stored
	static String[][] charactersArr = new String[3][20];
	static String[] gunmenArr = {"Han Solo", "Chewbacca", "Zorii Bliss", "Lando Calrissian"};
	static String[] driversArr = {"Finn", "Snap Wexley", "Maz Kanata", "Poe Dameron"};
	static String[] hackersArr = {"C-3PO", "IG-88", "EV-9D9", "BB-8"};

	public static void main(String[] args)
	{
		menu(); // calls menu method
	}

	// The menu() function is the main game loop
	public static void menu()
	{
		while(running) // while runnning equals true, this loop continues
		{
		System.out.print("Star Wars: Galactic Criminality\n\nMain Menu:"
				+ "\n1. Build Crew"
				+ "\n2. Mission Select"
				+ "\n3. View your characters"
				+ "\nEnter quit to quit\n"
				+ "\nEnter selection number: "); // prints out main menu
		String select = scanner.next(); // saves user's selection

		// Switch case for the main menu selection
			switch (select)
			{
			  case "1":
			    buildCrew(); // calls buildCrew method
			    break;
			  case "2":
				 displayMissions(); // calls displayMissions method
			    break;
			  case "3":
				 viewYourCharacters(); // calls viewYourCharacters method
			    break;
			  case "quit":
			  	running = false; // ends game
			  	break;
			  default:
				System.out.println("Invalid Command");
			 }
		 }
	}

	public static void viewYourCharacters()
	{
		System.out.println("\nYour Gunmen:");
		for(int i=0; i<charactersArr.length; i++)
		{
		   if (charactersArr[0][0]==null) { // if you have no gunmen prints out none
			   System.out.println("None");
			   break;
		   }
		   if (charactersArr[0][i]!=null) { // if you do it prints out your gunmen
		     System.out.println(charactersArr[0][i]);
		   }
		}

		System.out.println("--------------\nYour Drivers:");
		for(int i=0; i<charactersArr.length; i++)
		{
			   if (charactersArr[1][0]==null) { // if you have no drivers prints out none
				   System.out.println("None");
				   break;
			   }
		   if (charactersArr[1][i]!=null) { // if you do it prints out your drivers
		     System.out.println(charactersArr[1][i]);
		   }
		}

		System.out.println("--------------\nYour Hackers:");
		for(int i=0; i<charactersArr.length; i++)
		{
			   if (charactersArr[2][0]==null) { // if you have no hackers prints out none
				   System.out.println("None");
				   break;
			   }
		   if (charactersArr[2][i]!=null) { // if you do it prints out your hackers
		     System.out.println(charactersArr[2][i]);
		   }
		}
		System.out.println();
	}

	public static void buildCrew()
	{
		System.out.print("\nBuild your crew"
				+ "\n---------------------------\n"
				+ "1. gunmen (100 credis)\n"
				+ "2. driver (100 credis)\n3. hacker (200 credis)\n"
				+ "\nCurrent Crew: " + gc.getGunmen() + " gunmen, " + gc.getDrivers()
				+ " drivers, " + gc.getHacker() + " hackers\nCurrent Credits: $"
				+ gc.getCredits() +"\nEnter b to go back" +"\n\nEnter selection number: "); // prints out the number of crew members you have and the cost to add more

		String select = scanner.next(); // saves user's selection
		// switch case to add a crew member
		switch (select)
		{
		  case "1":
			  gc.addGunmen(gc.getGunmen());
			  // selects a random gun men and subtracts credits
				int gunmenIndex = new Random().nextInt(gunmenArr.length);
				String randomgunmen = (gunmenArr[gunmenIndex]);
			  charactersArr[0][gc.getGunmen() - 1] = randomgunmen;
			  gc.subtract100Credits(gc.getCredits());
		    System.out.println("A gunmen was added their name is: " + charactersArr[0][gc.getGunmen() - 1] + "\n");
		    break;
		  case "2":
			  gc.addDrivers(gc.getDrivers());
			  // selects a random driver and subtracts credits
				int driverIndex = new Random().nextInt(driversArr.length);
				String randomDriver = (driversArr[driverIndex]);
			  charactersArr[1][gc.getDrivers() - 1] = randomDriver;
			  gc.subtract100Credits(gc.getCredits());
			 System.out.println("A driver was added their name is: " + charactersArr[1][gc.getDrivers() - 1] + "\n");
		    break;
		  case "3":
			  gc.addHacker(gc.getHacker());
			  // selects a random hacker and subtracts credits
				int hackerIndex = new Random().nextInt(hackersArr.length);
				String randomHacker = (hackersArr[hackerIndex]);
			  charactersArr[2][gc.getHacker() - 1] = randomHacker;
			  gc.subtract200Credits(gc.getCredits());
			  System.out.println("A hacker was added their name is: " + charactersArr[2][gc.getHacker() - 1] + "\n");
			 break;
		  case "b":
			  menu(); // goes back to main menu
			break;
		  default:
			System.out.println("Invalid Command\n");
		 }
	}
	// Prints out the missions-
	public static void displayMissions()
	{
		System.out.println("\nMisson Select"
				+ "\nEnter \"b\" to go back"
				+ "\n---------------------------"
				+ "\n1. Mos Eisley Cantina"
				+ "\n2. A minor spaceport savings bank"
				+ "\n3. Armored Money landspeeder"
				+ "\n4. Jewelry store of a major galactic jewelry franchise"
				+ "\n5. The Galactic Empire�s gold depository"
				+ "\nEnter b to go back to the main menu\n"); // prints available missions
		choice(); // calls choice method
	}

	public static void choice()
	{
		System.out.print("Enter Mission number: "); // asks user to choose a mission
		String select = scanner.next(); // saves user's choice
		System.out.println();
		switch (select) {
		  case "1":
		    mission1(); // calls mission1 method
		    break;
		  case "2":
		    mission2(); // calls mission2 method
		    break;
		  case "3":
		    mission3(); // calls mission3 method
		    break;
		  case "4":
		    mission4(); // calls mission4 method
		    break;
		  case "5":
		    mission5(); // calls mission5 method
		    break;
		  case "b":
		  	menu(); // goes back to main menu
		  	break;
		  default:
			System.out.println("Invalid Command\n");
			displayMissions();
		}
	}
	// arguments are gunner, driver, hacker, and mission number
	public static void requirements(int g, int d, int h, int m)
	{
		if(select() != true) // if select method returns false
		{
			displayMissions(); // calls displayMissoins
		}
		// Checks if crew requirement is met
		else if(crew(g, d, h) == true) // otherwise if crew method returns true
		{
			MosEisleyCantina s1 = new MosEisleyCantina();
			startMission2 s2 = new startMission2();
			LandSpeeder s3 = new LandSpeeder();
			JewelStoreOne s4 = new JewelStoreOne();
			GalacticEmpiresGoldDepository s5 = new GalacticEmpiresGoldDepository(); // creates objects to use each job class
			System.out.println("\nWelcome to mission " + m);
			switch (m) // uses m variable to call each job
			{
			  case 1:
				  gc.setCredits(s1.begin1(charactersArr)+gc.getCredits()); // calls Jonathan Walker's code
				  System.out.println("You now have "+gc.getCredits()+" credits.");
				  displayMissions();
			    break;
			  case 2:
				  // calls Miles Trammell's code
				  gc.setCredits(s2.begin2(charactersArr)+gc.getCredits());
				  System.out.println("You now have "+gc.getCredits()+" credits.");
				  displayMissions();
				 break;
			  case 3:
				  // calls Noah Vanderhoff's code
				  gc.setCredits(s3.begin3()+gc.getCredits());
				  System.out.println("You now have "+gc.getCredits()+" credits.");
				  displayMissions();
				break;
			  case 4:
				  // calls Ashley Philbeck's code
				  gc.setCredits(s4.begin4(charactersArr)+gc.getCredits());
				  System.out.println("You now have "+gc.getCredits()+" credits.");
				  displayMissions();
				break;
			  case 5:
				  gc.setCredits(s5.begin5(charactersArr)+gc.getCredits()); // calls carson week's code
				  System.out.println("You now have "+gc.getCredits()+" credits.");
				  displayMissions();
				break;
			  default:
				System.out.println("Invalid Command\n");
			 }
		}
		else
		{
			displayMissions();
		}
		running = false;
	}

	public static void mission5() // dispalys details for misssion 5
	{
		System.out.println("5. The Galactic Empire�s gold depository"
				+ "\na. Difficulty: 5 out of 5"
				+ "\nb. Success rate: 25%"
				+ "\nc. Crew: 3 gunmen, 3 drivers, 1 hacker"
				+ "\nd. Take: 3 billion credits\n");
		// edit arguments to change required crew and mission number
		requirements(3, 3, 1, 5); // calls requirements method and sends number of each crew and mission number
	}

	public static void mission4() // dispalys details for misssion 4
	{
		System.out.println("4. Jewelry store of a major galactic jewelry franchise"
				+ "\na. Difficulty: 4 out of 5"
				+ "\nb. Success rate: 61%"
				+ "\nc. Crew required: 1 gunman, 1 driver, 1 hacker"
				+ "\nd. Take 3,950,000-4,975,000 credits\n");
		requirements(1, 1, 1, 4); // calls requirements method and sends number of each crew and mission number
	}

	public static void mission3() // dispalys details for misssion 3
	{
		System.out.println("3. Armored Money landspeeder"
				+ "\na. Difficulty: 2 out of 5"
				+ "\nb. Success rate: 79%"
				+ "\nc. Crew required: none"
				+ "\nd. Take: 25,000-30,000 credits\n");
		requirements(0, 0, 0, 3); // calls requirements method and sends number of each crew and mission number
	}

	public static void mission2() // dispalys details for misssion 2
	{
		System.out.println("2. A minor spaceport savings bank"
				+ "\na. Difficulty: 3 out of 5"
				+ "\nb. Success rate: 72%"
				+ "\nc. Crew required: 1 gunman, 1 driver, 1 hacker"
				+ "\nd. Take: 40,000 credits\n");
		requirements(1, 1, 1, 2); // calls requirements method and sends number of each crew and mission number
	}

	public static void mission1() // dispalys details for misssion 1
	{
		System.out.println("1. Mos Eisley Cantina"
				+ "\na. Difficulty: 2 out of 5"
				+ "\nb. Success rate: 80%"
				+ "\nc. Crew required: 1 gunman, 0 drivers, 0 hackers"
				+ "\nd. Take: 5000 credits\n");
		requirements(1, 0, 0, 1); // calls requirements method and sends number of each crew and mission number
	}

	public static boolean select()
	{
		System.out.print("Continue?(y/n): "); // asks you if they want to continue
		String select = scanner.next(); // saves input
		if(select.equalsIgnoreCase("y")) // if input equals y
		{
			return true; // returns true
		}
		else // if it equals anythin else
		{
			return false; // returns false
		}
	}

	public static boolean crew(int g, int d, int h)
	{
		if(gc.getGunmen() < g || gc.getDrivers() < d || gc.getHacker() < h) // checks if user has required crew
		{
			System.out.println("\nMissing required crew!" // if not it tells user what they are missing
					+ "\nRequired Crew: " + (g - gc.getGunmen()) + " gunmen, " + (d - gc.getDrivers()) + " drivers, " + (h - gc.getHacker()) + " hackers"
					+ "\nCurrent Crew: " + gc.getGunmen() + " gunmen, " + gc.getDrivers() + " drivers, " + gc.getHacker() + " hackers");
			return false; // returns false
		}
		return true; // if they do then it returns true
	}
}




