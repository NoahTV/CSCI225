/**
 * GalacticEmpiresGoldDepository.java
 *
 * GalacticEmpiresGoldDepository application
 *
 * Carson Weeks
 * crweeks@usca.edu
 * Final project job #7: Galactic Empire's Gold Depository Heist
 * Last modified: 04/26/2020
 * @version 1.00
 */

public class GalacticEmpiresGoldDepository {

    public double begin5(String[][] c) {

    	String gunman1 = c[0][0];
    	String gunman2 = c[0][1];
    	String gunman3 = c[0][2];
    	String hacker = c[2][0];
    	String driver1 = c[1][0];
    	String driver2 = c[1][1];
    	String driver3 = c[1][2];
    	double dice=(Math.random()*100);// Noah used the dice and math in his code, so I think those would work for the other jobs, including this one.

		System.out.println("You "+hacker+" "+gunman1+" and "+gunman2+" approach the Galactic Empire's Gold Depository.");
    	System.out.println("You all get off the ships and and get into position while "+driver1+" along with "+driver3+" waits on stand by.");
    	System.out.println("On another ship "+driver2+" waits on stand by with "+gunman3+" in case of reinforcements.");
    	System.out.println("You all have heavy armor and the gunmans have heavier blaster rifles.");
    	System.out.println("You all move towards the door with which has a blast shield activated.");
    	System.out.println("You wait for the hacker to deactivate the shield while the "+gunman1+" sets up position outside.");

    	// changed the success rate to 25 percent because it's one of the more difficult jobs
    	// so if the dice roll is less than or equal to 25, then the job gets done without any trouble
    	if(dice <= 25)
    	{
    		System.out.println("The hacker manages to deactivate the shield.");
    		System.out.println("You and "+gunman2+" enter the building and take care of the guards.");
    		System.out.println("you both begin to load up all of the credits into the ships with "+driver1+" and "+driver3+".");
    		System.out.println("You manage to escape with the whole depository looted.");
    		System.out.println("Both ships are able to make it off and you all split it between the 8 of you evenly.");
    		return 428571429;
    	}
    	// if the dice is greater than 25
    	else
    	{
    		System.out.println("The guards are put on a heavy fight and were able to call in reinforcements.");
    		System.out.println(""+gunman3+" along with "+driver2+" tries to fend off the reinforcements but are no match.");
    		System.out.println("you and the two remaining gunmen get back on to the ships and enter hyperspace to evade anymore trouble.");
    		System.out.println("You all managed to get away with but only with your lives.");
    		return 0;
    	}
    }
}
